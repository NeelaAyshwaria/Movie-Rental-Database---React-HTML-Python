""" Binding MySQL """

from flaskext.mysql import MySQL

mysql = MySQL()
