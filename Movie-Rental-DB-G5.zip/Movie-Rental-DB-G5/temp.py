#--------------------------------------------------------------------------------------------
# RENTAL MODEL
#--------------------------------------------------------------------------------------------

CREATE_GENRE_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
genre_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
genre_name VARCHAR(30) NOT NULL
)
""".format(database=MYSQL_DATABASE_DB, table=GENRE_TABLE).replace('\n', ' ')

CREATE_MOVIE_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
movie_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
movie_title VARCHAR(40) NOT NULL,
movie_release_date  DATE NOT NULL,
movie_details VARCHAR(200) NOT NULL
)
""".format(database=MYSQL_DATABASE_DB, table=MOVIE_TABLE).replace('\n', ' ')

CREATE_MOVIE_GENRE_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
movie_genre_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
movie_id INT,
FOREIGN KEY (movie_id) REFERENCES movie(movie_id),
genre_id INT,
FOREIGN KEY (genre_id) REFERENCES genre(genre_id)
)
""".format(database=MYSQL_DATABASE_DB, table=MOVIE_GENRE_TABLE).replace('\n', ' ')

CREATE_ACTOR_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
actor_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
actor_first_name VARCHAR(80) NOT NULL,
actor_last_name VARCHAR(80) NOT NULL,
actor_born_date DATE NOT NULL,
actor_born_country VARCHAR(60) NOT NULL,
actor_death_date DATE NULL
)
""".format(database=MYSQL_DATABASE_DB, table=ACTOR_TABLE).replace('\n', ' ')

CREATE_MOVIE_ACTOR_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
actor_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
actor_first_name VARCHAR(80) NOT NULL,
actor_last_name VARCHAR(80) NOT NULL,
actor_born_date DATE NOT NULL,
actor_born_country VARCHAR(60) NOT NULL,
actor_death_date DATE NULL
)
""".format(database=MYSQL_DATABASE_DB, table=MOVIE_ACTOR_TABLE).replace('\n', ' ')

CREATE_DIRECTOR_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
director_id  INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
director_first_name VARCHAR(80) NOT NULL,
director_last_name VARCHAR(80) NOT NULL,
director_born_date DATE NOT NULL,
director_born_country VARCHAR(60) NOT NULL,
director_death_date DATE NULL
)
""".format(database=MYSQL_DATABASE_DB, table=DIRECTOR_TABLE).replace('\n', ' ')

CREATE_MOVIE_DIRECTOR_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
movie_director_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
movie_id INT,
FOREIGN KEY (movie_id) REFERENCES movie(movie_id),
director_id INT,
FOREIGN KEY (director_id) REFERENCES director(director_id)
)
""".format(database=MYSQL_DATABASE_DB, table=MOVIE_DIRECTOR_TABLE).replace('\n', ' ')

CREATE_RATINGS_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
rating_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
rating_name VARCHAR(25) NOT NULL UNIQUE
)
""".format(database=MYSQL_DATABASE_DB, table=RATINGS_TABLE).replace('\n', ' ')

CREATE_MOVIE_RATINGS_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
rating_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
rating_name VARCHAR(25) NOT NULL UNIQUE
)
""".format(database=MYSQL_DATABASE_DB, table=MOVIE_RATINGS_TABLE).replace('\n', ' ')

CREATE_RENTAL_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
rental_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
user_id INT,
FOREIGN KEY (user_id) REFERENCES user(user_id),
movie_id INT,
FOREIGN KEY (movie_id) REFERENCES movie(movie_id),
borrowed_date DATE NOT NULL,
return_date DATE NULL,
due_date DATE NOT NULL
)
""".format(database=MYSQL_DATABASE_DB, table=RENTAL_TABLE).replace('\n', ' ')


#--------------------------------------------------------------------------------------------
# USERS MODEL
#--------------------------------------------------------------------------------------------

CREATE_PERSON_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
person_id  INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
username VARCHAR(60) NOT NULL UNIQUE,
user_pass VARCHAR(50) NOT NULL,
first_name VARCHAR(80) NOT NULL,
last_name VARCHAR(80) NOT NULL,
birthdate DATE NOT NULL,
street VARCHAR(100) NOT NULL,
city VARCHAR(65) NULL,
state VARCHAR(50) NOT NULL,
zip INT,
phone VARCHAR(16) NOT NULL,
email  VARCHAR(70) NOT NULL,
data_joined DATE NOT NULL
)
""".format(database=MYSQL_DATABASE_DB, table=PERSON_TABLE).replace('\n', ' ')

INSERT_PERSON_TABLE = """INSERT INTO {database}.{table}
(username, password, first_name, last_name, birthdate, street, city, state,
zip, phone, email, data_joined)
VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
""".format(database=MYSQL_DATABASE_DB, table=PERSON_TABLE).replace('\n', ' ')

CREATE_USER_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
user_id INT PRIMARY KEY NOT NULL,
person_id INT,
FOREIGN KEY (person_id) REFERENCES person(person_id)
)
""".format(database=MYSQL_DATABASE_DB, table=USER_TABLE).replace('\n', ' ')

INSERT_USER_TABLE = """INSERT INTO {database}.{table} (user_id, person_id)
VALUES (%s, %s)
""".format(database=MYSQL_DATABASE_DB, table=USER_TABLE).replace('\n', ' ')

CREATE_ADMIN_TABLE = """CREATE TABLE IF NOT EXISTS {database}.{table} (
admin_id  INT PRIMARY KEY NOT NULL,
person_id INT,
FOREIGN KEY (person_id) REFERENCES person(person_id)
)
""".format(database=MYSQL_DATABASE_DB, table=ADMIN_TABLE).replace('\n', ' ')

INSERT_ADMIN_TABLE = """INSERT INTO {database}.{table} (
public_id, first_name, last_name, email, username, password, is_admin) 
VALUES (%s, %s)
""".format(database=MYSQL_DATABASE_DB, table=ADMIN_TABLE).replace('\n', ' ')